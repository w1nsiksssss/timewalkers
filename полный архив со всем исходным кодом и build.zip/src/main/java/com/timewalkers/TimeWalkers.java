package com.timewalkers;

import com.timewalkers.containers.MenuTypes;
import com.timewalkers.init.BlockInit;
import com.timewalkers.init.*;
import com.timewalkers.init.TabInit;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod("timewalkers")
public class TimeWalkers {
    public static final String MOD_ID = "timewalkers";
        private static final Logger LOGGER = LoggerFactory.getLogger(TimeWalkers.class);

    // Регистрация блоков
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);

    // Регистрация предметов
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    // Таблицы креативного меню

    public TimeWalkers() {

        Thread.setDefaultUncaughtExceptionHandler((thread, ex) -> {
            LOGGER.error("Uncaught exception occurred in thread {}: {}", thread.getName(), ex.toString());
            ex.printStackTrace();
        });
        FMLJavaModLoadingContext.get().getModEventBus().register(this);

        TabInit.register(FMLJavaModLoadingContext.get().getModEventBus());
        // Регистрация блоков
        BlockInit.register(FMLJavaModLoadingContext.get().getModEventBus());

        // Регистрация предметов
        ItemInit.register(FMLJavaModLoadingContext.get().getModEventBus());

        MenuTypes.register(FMLJavaModLoadingContext.get().getModEventBus());
// Инициализация табов

    }
}