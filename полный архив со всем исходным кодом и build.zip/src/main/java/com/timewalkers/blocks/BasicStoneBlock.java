package com.timewalkers.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;

public class BasicStoneBlock extends Block {

    public BasicStoneBlock() {
        super(Properties.of(Material.STONE)
                .strength(3.0F, 10.0F) // Жёсткость и ударопрочность
                .sound(SoundType.STONE)); // Звук блока
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter worldIn, BlockPos pos) {
        return 1.0F; // Яркость тени
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
        return true; // Пропускает свет сверху
    }
}