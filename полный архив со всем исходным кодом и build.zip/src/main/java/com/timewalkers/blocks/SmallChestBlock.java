package com.timewalkers.blocks;

import com.timewalkers.init.BlockInit;
import com.timewalkers.init.ItemInit;
import com.timewalkers.tileentities.TileEntitySmallChest;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nonnull;

public class SmallChestBlock extends ChestBlock {

    public SmallChestBlock(BlockBehaviour.Properties properties) {
        super(properties, () -> BlockEntityType.Builder.of(TileEntitySmallChest::new, BlockInit.SMALL_CHEST_BLOCK.get()).build(null));
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && !player.isSpectator()) {
            player.openMenu(state.getMenuProvider(level, pos));
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter getter, BlockPos pos, CollisionContext context) {
        return Shapes.joinUnoptimized(Shapes.box(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D), Shapes.box(0.0D, 0.5D, 0.0D, 1.0D, 1.0D, 1.0D), BooleanOp.OR);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TileEntitySmallChest(pos, state);
    }
    @Nonnull
    public ItemStack getCloneItemStack(BlockState state, HitResult target, Level world, BlockPos pos, Player player) {
        // Возвращаем ItemStack для Small Chest Item
        Item smallChestItem = ItemInit.SMALL_CHEST_ITEM.get(); // Получаем Item из DeferredRegister
        return new ItemStack(smallChestItem); // Создаем ItemStack из Item
    }
}