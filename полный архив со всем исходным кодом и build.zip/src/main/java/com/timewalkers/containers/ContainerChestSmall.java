package com.timewalkers.containers;

import com.timewalkers.tileentities.InventoryChestSmall;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

public class ContainerChestSmall extends AbstractContainerMenu {

    private final InventoryChestSmall chestInventory;
    private final Player player;

    public ContainerChestSmall(MenuType<?> type, int id, Inventory playerInv, BlockPos pos) {
        super(type, id);
        this.chestInventory = new InventoryChestSmall(9); // Создаём инвентарь с 9 слотами
        this.player = playerInv.player;

        addPlayerSlots(playerInv);
        addOwnSlots(chestInventory);
    }


    private void addPlayerSlots(Inventory playerInv) {
        // Игровые слоты игрока (обычные слоты персонажа)
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        // Слоты быстрого доступа (горячая панель)
        for (int hotbarIndex = 0; hotbarIndex < 9; ++hotbarIndex) {
            this.addSlot(new Slot(playerInv, hotbarIndex, 8 + hotbarIndex * 18, 142));
        }
    }

    private void addOwnSlots(InventoryChestSmall inventory) {
        // Собственные слоты сундука (только верхний ряд)
        for (int slotIndex = 0; slotIndex < inventory.getContainerSize(); ++slotIndex) {
            this.addSlot(new Slot(inventory, slotIndex, 8 + slotIndex * 18, 18));
        }
    }

    @Override
    public boolean stillValid(Player p_38874_) {
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack stack = ItemStack.EMPTY;
        Slot slot = slots.get(index);

        if (!slot.hasItem()) return ItemStack.EMPTY;

        ItemStack originalStack = slot.getItem();
        stack = originalStack.copy();

        // Перемещение между слотами
        if (index >= chestInventory.getContainerSize()) {
            // Из инвентаря игрока в сундук
            if (!this.moveItemStackTo(originalStack, 0, chestInventory.getContainerSize(), false))
                return ItemStack.EMPTY;
            else {
                if (!this.moveItemStackTo(originalStack, chestInventory.getContainerSize(), slots.size(), false))
                    return ItemStack.EMPTY;
            }

            if (originalStack.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }

            return stack;
        }
        return stack;
    }
}
