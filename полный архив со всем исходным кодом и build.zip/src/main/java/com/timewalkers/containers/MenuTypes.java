package com.timewalkers.containers;

import com.timewalkers.TimeWalkers;
import com.timewalkers.containers.ContainerChestSmall;
import com.timewalkers.tileentities.InventoryChestSmall;
import net.minecraft.core.BlockPos;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class MenuTypes {

    public static final DeferredRegister<MenuType<?>> CONTAINERS = DeferredRegister.create(ForgeRegistries.CONTAINERS, TimeWalkers.MOD_ID);

    public static final RegistryObject<MenuType<ContainerChestSmall>> CONTAINER_SMALL_CHEST =
            CONTAINERS.register("small_chest_container", () -> IForgeMenuType.create((windowId, inv, data) -> {
                BlockPos pos = data.readBlockPos(); // Читаем позицию блока из буфера
                return new ContainerChestSmall(MenuTypes.CONTAINER_SMALL_CHEST.get(), windowId, inv, pos); // Передаём в конструктор
            }));
    public static void register(IEventBus bus) {
        CONTAINERS.register(bus);

    }
}