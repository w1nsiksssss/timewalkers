package com.timewalkers.events;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.event.lifecycle.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EventHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EventHandler.class);

    @SubscribeEvent
    public static void onLoadComplete(FMLLoadCompleteEvent event) {
        LOGGER.info("Мод TimeWalkers завершил загрузку.");
    }

    @SubscribeEvent
    public static void onClientStart(FMLClientSetupEvent event) {
        LOGGER.info("Клиентская сторона мода готова.");
    }

    @SubscribeEvent
    public static void onInitialization(FMLCommonSetupEvent event) {
        LOGGER.info("Завершается общая инициализация мода.");
    }
}