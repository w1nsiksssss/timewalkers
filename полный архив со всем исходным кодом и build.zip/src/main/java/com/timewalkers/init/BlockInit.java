package com.timewalkers.init;

import com.timewalkers.TimeWalkers;
import com.timewalkers.blocks.BasicStoneBlock;
import com.timewalkers.blocks.SmallChestBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class BlockInit {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TimeWalkers.MOD_ID);

    // Регистрация блока
    public static final RegistryObject<Block> BASIC_STONE_BLOCK = BLOCKS.register("basic_stone_block", BasicStoneBlock::new);
    public static final RegistryObject<Block> SMALL_CHEST_BLOCK = BLOCKS.register("small_chest", () -> new SmallChestBlock(Block.Properties.of(Material.STONE).strength(2.5F)));

    // Это метод, который автоматически создаёт предмет (блок-предмет) для каждого зарегистрированного блока
    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);

        // Создаём объект предмет-блок и связываем его с нашей табличкой
        ItemInit.ITEMS.register("basic_stone_block", () ->
                new BlockItem(BASIC_STONE_BLOCK.get(), new Item.Properties().tab(TabInit.BLOCKS_TAB))
        );

    }
}