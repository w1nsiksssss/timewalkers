package com.timewalkers.init;

import com.timewalkers.TimeWalkers;
import com.timewalkers.items.LongStick;
import com.timewalkers.items.LeatherScrap;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TimeWalkers.MOD_ID);

    // Эти строки относятся к обычному процессу регистрации обычных предметов
    public static final RegistryObject<Item> LONG_STICK = ITEMS.register("long_stick", () -> new LongStick(new Item.Properties().tab(TabInit.TOOLS_TAB).durability(1)));
    public static final RegistryObject<Item> LEATHER_SCRAP = ITEMS.register("leather_scrap", () -> new LeatherScrap(new Item.Properties().tab(TabInit.MISC_TAB).stacksTo(64)));
    public static final RegistryObject<Item> SMALL_CHEST_ITEM = ITEMS.register("small_chest", () -> new BlockItem(BlockInit.SMALL_CHEST_BLOCK.get(), new Item.Properties().tab(TabInit.BLOCKS_TAB)));

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
    }
}