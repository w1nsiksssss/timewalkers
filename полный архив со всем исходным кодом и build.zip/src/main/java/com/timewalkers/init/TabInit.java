package com.timewalkers.init;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;

public class TabInit {

    // Объявляем вкладки статическими, но не инициализируем их сразу.
    public static CreativeModeTab WEAPONS_TAB;
    public static CreativeModeTab ARMOR_TAB;
    public static CreativeModeTab BLOCKS_TAB;
    public static CreativeModeTab TOOLS_TAB;
    public static CreativeModeTab MISC_TAB;
    public static CreativeModeTab MATERIALS_TAB;
    public static CreativeModeTab DECORATIONS_TAB;

    public static void register(IEventBus modEventBus) {
        WEAPONS_TAB = new CreativeModeTab("weapons_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LONG_STICK.get());
            }
        };

        ARMOR_TAB = new CreativeModeTab("armor_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LONG_STICK.get());
            }
        };

        BLOCKS_TAB = new CreativeModeTab("blocks_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LONG_STICK.get());
            }
        };

        TOOLS_TAB = new CreativeModeTab("tools_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LONG_STICK.get());
            }
        };

        MISC_TAB = new CreativeModeTab("misc_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LEATHER_SCRAP.get());
            }
        };

        MATERIALS_TAB = new CreativeModeTab("materials_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LEATHER_SCRAP.get());
            }
        };

        DECORATIONS_TAB = new CreativeModeTab("decorations_tab") {
            @Override
            public ItemStack makeIcon() {
                return new ItemStack(ItemInit.LEATHER_SCRAP.get());
            }
        };
    }
}