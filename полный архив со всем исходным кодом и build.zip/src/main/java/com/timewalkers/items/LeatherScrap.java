package com.timewalkers.items;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;

public class LeatherScrap extends Item {
    public LeatherScrap(Properties properties) {
        super(properties);
    }
}