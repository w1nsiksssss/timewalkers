package com.timewalkers.items;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.RegistryObject;
import com.timewalkers.init.ItemInit;

public class LongStick extends Item {

    public LongStick(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        // Получаем вектор взгляда игрока
        Vec3 start = player.getEyePosition(1.0F);
        Vec3 viewVector = player.getLookAngle();
        Vec3 end = start.add(viewVector.scale(5.0D)); // максимальная дистанция — 5 блоков

        // Находим блок, на который смотрит игрок
        HitResult rayTraceResult = player.pick(5.0D, 1.0F, false); // Радиус поиска — 5 метров
        if (rayTraceResult != null && rayTraceResult.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockRayTraceResult = (BlockHitResult) rayTraceResult;
            BlockPos blockPos = blockRayTraceResult.getBlockPos();
            BlockState state = world.getBlockState(blockPos);

            // Устанавливаем огонь НАД блоком, а не замещаем его
            if (!state.isAir() && !state.getFluidState().is(FluidTags.WATER)) {
                BlockPos firePos = blockPos.above(); // Огонь ставится НАД блоком
                world.setBlockAndUpdate(firePos, Blocks.FIRE.defaultBlockState());

                // Звук розжига
                world.playSound(null, firePos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 1.0F, 1.0F);

                // Генерируем событие размещения
                world.gameEvent(player, GameEvent.BLOCK_PLACE, firePos);

                // Уменьшаем количество палок на 1
                itemStack.shrink(1);
            }
        }

        return InteractionResultHolder.success(itemStack);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        return InteractionResult.PASS;
    }
}