package com.timewalkers.tileentities;

import com.timewalkers.TimeWalkers;
import com.timewalkers.init.BlockInit;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class BlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> TILE_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES, TimeWalkers.MOD_ID);

    public static final RegistryObject<BlockEntityType<TileEntitySmallChest>> SMALL_CHEST_ENTITY_TYPE =
            TILE_ENTITIES.register("small_chest_entity_type", () -> BlockEntityType.Builder.of(TileEntitySmallChest::new, BlockInit.SMALL_CHEST_BLOCK.get()).build(null));

    public static void register(IEventBus bus) {
        TILE_ENTITIES.register(bus);
    }
}