package com.timewalkers.tileentities;

import net.minecraft.ChatFormatting;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InventoryChestSmall extends SimpleContainer {

    public InventoryChestSmall(int size) {
        super(size);
    }
    public NonNullList<ItemStack> getItems() {
        NonNullList<ItemStack> result = NonNullList.create();
        for (int i = 0; i < this.getContainerSize(); i++) {
            result.add(this.getItem(i));
        }
        return result;
    }


    public Component getDisplayName() {
        return new TranslatableComponent("container.small_chest");
    }

    @Override
    public void setChanged() {
        super.setChanged();
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < this.getContainerSize(); ++i) {
            this.setItem(i, ItemStack.EMPTY);
        }
    }
    public CompoundTag save(CompoundTag nbt) {
        ContainerHelper.saveAllItems(nbt, this.getItems());
        return nbt;
    }

    public void load(CompoundTag nbt) {
        ContainerHelper.loadAllItems(nbt, this.getItems());
    }
}