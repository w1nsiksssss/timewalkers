package com.timewalkers.tileentities;

import com.timewalkers.containers.ContainerChestSmall;
import com.timewalkers.containers.MenuTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class TileEntitySmallChest extends ChestBlockEntity implements MenuProvider {

    private final InventoryChestSmall chestInventory = new InventoryChestSmall(9); // Всего 9 слотов

    public TileEntitySmallChest(BlockPos pos, BlockState state) {
        super(BlockEntities.SMALL_CHEST_ENTITY_TYPE.get(), pos, state);
    }

    @Override
    public Component getDisplayName() {
        return new TranslatableComponent("container.small_chest");
    }

    @Override
    public AbstractContainerMenu createMenu(int windowID, Inventory inv, Player player) {
        return new ContainerChestSmall(MenuTypes.CONTAINER_SMALL_CHEST.get(), windowID, inv, this.getBlockPos()); // передаём позицию блока
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        chestInventory.load(tag.getCompound("inventory"));
    }

    @Override
    public void saveAdditional(CompoundTag compound) {
        super.saveAdditional(compound);
        compound.put("inventory", chestInventory.save(new CompoundTag()));
    }

    public InventoryChestSmall getChestInventory() {
        return chestInventory;
    }
}
